# Sprint 2 – Bitwig Bridge (Track Targeting)

## Summary
Implement Java `.bwextension` bridge with a local WebSocket API for deterministic track/device targeting, plus a Python client.

## Related
- Closes: #<IssueNr>
- Base: `main`
- Compare: `feature/sprint2-bitwig-bridge`

## Changes
- feat(extension): MCPBridgeExtension skeleton (Gradle project)
- feat(extension): WebSocket server (default `ws://127.0.0.1:7011`)
- feat(extension): Endpoints for track/device/params
- feat(py): `bridge_ws_client.py` + CLI `tools/bridge_probe.py`
- docs: `docs/README_Sprint2.md`
- test: Java unit tests (matching/parsing), Python client mocks
- chore: Gradle build & packaging to `.bwextension`
